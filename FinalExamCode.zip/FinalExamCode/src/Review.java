
public class Review {

	//attributes
	private Patient patient;
	private FeedbackList feedbackList;
	
	//default constructor
	public Review() {
		
	}

	//complete constructor
	public Review(Patient patient, FeedbackList feedbackList) {
		this.patient = patient;
		this.feedbackList = feedbackList;
	}

	//setter/getter
	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	
	public FeedbackList getFeedbackList() {
		return feedbackList;
	}

	public void setFeedbackList(FeedbackList feedbackList) {
		this.feedbackList = feedbackList;
	}

	//other methods
	//to display reviews
	public void displayReviews() {
		System.out.printf("\n\n---------\n");
		System.out.printf("|REVIEWS|");
		System.out.printf("\n---------\n");
		System.out.printf("\nUsername: %s", patient.getUsername());
		feedbackList.displayFeedbackList();
	}
	
	//toString
	@Override
	public String toString() {
		return String.format("Review [patient = %s, feedbackList=%s]", patient, feedbackList);
	}
}
