
public class Patient extends User {

	//attributes
	private String nextOfKin;
	private String medicalHistory;
	private Feedback feedback;
	
	//default constructor
	public Patient() {
		
	}

	//complete constructor
	public Patient(String firstName, String lastName, String username, String birthday, String phoneNum, String email,
			String password, String nextOfKin, String medicalHistory, Feedback feedback) {
		super(firstName, lastName, username, birthday, phoneNum, email, password);
		this.nextOfKin = nextOfKin;
		this.medicalHistory = medicalHistory;
		this.feedback = feedback;
		
	}

	//setter/getter
	public String getNextOfKin() {
		return nextOfKin;
	}

	public void setNextOfKin(String nextOfKin) {
		this.nextOfKin = nextOfKin;
	}

	public String getMedicalHistory() {
		return medicalHistory;
	}

	public void setMedicalHistory(String medicalHistory) {
		this.medicalHistory = medicalHistory;
	}

	public Feedback getFeedback() {
		return feedback;
	}

	public void setFeedback(Feedback feedback) {
		this.feedback = feedback;
	}

	//toString
	@Override
	public String toString() {
		return String.format("Patient [%s, nextOfKin=%s, medicalHistory=%s]", super.toString() ,nextOfKin, medicalHistory);
	}	
}
