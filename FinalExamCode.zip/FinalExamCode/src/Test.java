
public class Test {

	public static void main(String[] args) {
		
		//creating a review
		Review review1 = new Review();
		
		//creating a therapist
		Therapist therapist1 = new Therapist("Dr Choo", "Kang", "ckang67", "23/06/1971", "0182061621", "ckang67@gmail.com", "laicheekang23", "Cognitive and Behavioral", "Cognitive, Behavior, Psychoanalysis", review1);
		
		//creating feedback for patient
		Feedback feedback1 = new Feedback("Nice, skilled, and super polite. Will see him again soon for my next appointment!", therapist1);
		
		//creating a patient
		Patient p1 = new Patient("Rachel", "Green", "rachel78", "17/06/2001", "0132829713", "rachGreen@gmail.com",
				"rosslover56", "Christina", "Clinical Depression", feedback1);
		
		//creating feedback list
		FeedbackList flist = new FeedbackList();
		
		//adding feedback into feedback list
		flist.addEntry(feedback1);
	
		//making an appointment
		Appointment appt1 = new Appointment("01/07/2022, 2-4pm", p1, "No", therapist1);
		
		//display 'Book an Appointment' interface
		appt1.displayBookAppointment();
		
		//generating booking confirmation
		Confirmation c1 = new Confirmation(appt1);
		
		//printing out booking confirmation
		c1.displayAppointmentConfirmation();
		
		//after the appointment, patient leaves feedback 
		flist.displayFeedbackList();
		
		//after patient leaves feedback, feedback enters review page
		Review r1 = new Review(p1, flist);
		
		//display reviews
		r1.displayReviews();
		
	}
}
