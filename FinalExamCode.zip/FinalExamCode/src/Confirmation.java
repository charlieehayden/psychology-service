
public class Confirmation {

	//attributes
	private Appointment appt;
	
	//default constructor
	public Confirmation() {
		
	}
	
	//complete constructor
	public Confirmation(Appointment appt) {
		this.appt = appt;
	}

	//setter/getter
	public Appointment getAppt() {
		return appt;
	}

	public void setAppt(Appointment appt) {
		this.appt = appt;
	}

	//other methods
	//to display appointment confirmation
	public void displayAppointmentConfirmation() {
		System.out.printf("\n\n----------------------\n");
		System.out.printf("|BOOKING CONFIRMATION|\n");
		System.out.printf("----------------------\n\n");
		System.out.printf("CONGRATULATIONS!\n");
		System.out.printf("You have successfully made the appointment!\n\n");
		appt.displayBookingConfirmationInfo();
		System.out.printf("\nIf you wish to change or cancel your appointment,\n");
		System.out.printf("please proceed to change/cancel appointment for more details.");
	}
	
	//toString
	@Override
	public String toString() {
		return String.format("Confirmation [appt=%s]", appt);
	}
}
