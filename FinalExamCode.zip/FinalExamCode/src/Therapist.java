
public class Therapist extends User {

	//attributes
	private String areaOfSpec;
	private String servicesOffered;
	private Review review;
	
	//default constructor
	public Therapist() {
		
	}

	//complete constructor
	public Therapist(String firstName, String lastName, String username, String birthday, String phoneNum, String email,
			String password, String areaOfSpec, String servicesOffered, Review review) {
		super(firstName, lastName, username, birthday, phoneNum, email, password);
		this.areaOfSpec = areaOfSpec;
		this.servicesOffered = servicesOffered;
		this.review = review;
	}

	//setter/getter
	public String getAreaOfSpec() {
		return areaOfSpec;
	}

	public void setAreaOfSpec(String areaOfSpec) {
		this.areaOfSpec = areaOfSpec;
	}

	public String getServicesOffered() {
		return servicesOffered;
	}

	public void setServicesOffered(String servicesOffered) {
		this.servicesOffered = servicesOffered;
	}

	public Review getReview() {
		return review;
	}

	public void setReview(Review review) {
		this.review = review;
	}
	
	//other methods
	//to display therapist information
	public void displayTherapistInfo() {
		super.displayUserInfo();
		System.out.printf("Area of Specialty: %s\n", getAreaOfSpec());
		System.out.printf("Service offered: %s\n", getServicesOffered());
		System.out.printf("Reviews: %s", getReview());
	}
	
	//to display choice of therapist
	public void displayTherapistChoice() {
		System.out.printf("Therapist: %s", getFirstName(), getLastName());
	}

	//toString
	@Override
	public String toString() {
		return String.format("Therapist [%s, areaOfSpec=%s, servicesOffered=%s]", super.toString() ,areaOfSpec, servicesOffered);
	}
}
