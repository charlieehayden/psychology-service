
public class Feedback {

	//attributes
	private String comment;
	private Therapist therapist;
	
	//default constructor
	public Feedback() {
		
	}

	//complete constructor
	public Feedback(String comment, Therapist therapist) {
		this.comment = comment;
		this.therapist = therapist;
	}

	//setter/getter
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Therapist getTherapist() {
		return therapist;
	}

	public void setTherapist(Therapist therapist) {
		this.therapist = therapist;
	}
	
	//other methods
	//to display feedback information
	public void displayFeedbackInfo() {
		System.out.printf("\n\nFeedback: %s\n", getComment());
		therapist.displayTherapistChoice();
	}

	//toString
	@Override
	public String toString() {
		return String.format("Feedback [comment=%s, therapist=%s]", comment, therapist);
	}	
}
