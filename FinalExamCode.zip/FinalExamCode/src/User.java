
public class User {

	//attributes
	private String firstName;
	private String lastName;
	private String username;
	private String birthday;
	private String phoneNum;
	private String email;
	private String password;
	
	//default constructor
	public User() {
		
	}

	//complete constructor
	public User(String firstName, String lastName, String username, String birthday, String phoneNum, String email,
			String password) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.username = username;
		this.birthday = birthday;
		this.phoneNum = phoneNum;
		this.email = email;
		this.password = password;
	}
	
	//setter/getter
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	//other methods
	//to display user information
	public void displayUserInfo() {
		System.out.printf("Name: %s %s\n", getFirstName(), getLastName());
		System.out.printf("Contact number: %s\n", getPhoneNum());
		System.out.printf("Email address: %s\n", getEmail());
	}

	//toString
	@Override
	public String toString() {
		return String.format(
				"User [firstName=%s, lastName=%s, username=%s, birthday=%s, phoneNum=%s, email=%s, password=%s]",
				firstName, lastName, username, birthday, phoneNum, email, password);
	}
}
