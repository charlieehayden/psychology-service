import java.util.ArrayList;

public class FeedbackList {

	//attributes
	private ArrayList<Feedback> feedbackList = new ArrayList<Feedback>();
	
	
	//default constructor
	public FeedbackList() {
		
	}

	//complete constructor
	public FeedbackList(ArrayList<Feedback> feedbackList) {
		this.feedbackList = feedbackList;
	}

	//setter/getter
	public ArrayList<Feedback> getFeedbackList() {
		return feedbackList;
	}

	public void setFeedbackList(ArrayList<Feedback> feedbackList) {
		this.feedbackList = feedbackList;
	}
	
	//other methods
	//to display list of feedback
	public void displayFeedbackList() {
		
		for (Feedback f: feedbackList) {
			f.displayFeedbackInfo();
		}
	}
	
	//to add feedback into feedback list
	public void addEntry(Feedback f) {
		feedbackList.add(f);
	}

	//toString
	@Override
	public String toString() {
		return String.format("FeedbackList [feedbackList=%s]", feedbackList);
	}	
}
