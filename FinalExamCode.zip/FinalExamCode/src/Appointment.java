
public class Appointment {

	//attributes
	private String apptDate;
	private Patient patient;
	private String choice;
	private Therapist therapist;
	
	//default constructor
	public Appointment() {
		
	}

	//complete constructor
	public Appointment(String apptDate, Patient patient, String choice, Therapist therapist) {
		this.apptDate = apptDate;
		this.patient = patient;
		this.choice = choice;
		this.therapist = therapist;
	}

	//setter/getter
	public String getApptDate() {
		return apptDate;
	}

	public void setApptDate(String apptDate) {
		this.apptDate = apptDate;
	}

	public Patient getPatient() {
		return patient;
	}

	public void setPatient(Patient patient) {
		this.patient = patient;
	}

	public String getChoice() {
		return choice;
	}

	public void setChoice(String choice) {
		this.choice = choice;
	}
	
	public Therapist getTherapist() {
		return therapist;
	}

	public void setTherapist(Therapist therapist) {
		this.therapist = therapist;
	}

	//other methods
	//to display 'Book and Appointment' interface
	public void displayBookAppointment() {
		System.out.printf("---------------------------\n");
		System.out.printf("Important Notes:\n");
		System.out.printf("Please ensure your information is accurate.\n");
		System.out.printf("---------------------------\n");
		patient.displayUserInfo();
		System.out.printf("Appointment date: %s\n", getApptDate());
		System.out.printf("---------------------------\n");
		System.out.printf("\nDo you have any preferred therapist?\n");
		System.out.printf("If no, we will choose a therapist which is\nmore specialized to help you with.\n");
		System.out.printf("If yes, which therapist would you like to meet?\n");
		System.out.printf("\nChoice: %s\n", getChoice());
		therapist.displayTherapistChoice();
		System.out.printf("\n\n--------------------\n");
		System.out.printf("|SUBMIT APPOINTMENT|\n");
		System.out.printf("--------------------");
	}
	
	//to display appointment confirmation
	public void displayBookingConfirmationInfo() {
		System.out.printf("Booking Time: %s\n", getApptDate());
		System.out.printf("Therapist: %s\n", therapist.getFirstName());
	}
	
	//toString
	@Override
	public String toString() {
		return String.format("Appointment [apptDate=%s, patient=%s, therapist=%s]", apptDate, patient, therapist);
	}	
}
